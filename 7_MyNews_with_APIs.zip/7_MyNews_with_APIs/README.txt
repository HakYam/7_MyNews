npm i -g @stoplight/prism-cli

then TO run api

prism mock .\db.yaml
