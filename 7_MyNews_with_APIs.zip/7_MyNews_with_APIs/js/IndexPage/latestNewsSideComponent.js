const LNSnews = `
<div class="row ">
<div class="col-sm-6">
<a href="" class="article-link">
    <img src="" alt="وصف الصورة">
</a>
</div>
<div class="col-sm-6" id="latest-news-side-component">
<a href="" class="article-link">
    <div class="card-text">
        <span class="article-category"></span>
        <h5 class="article-title"> </h5>
    </div>
</a>
</div>
</div>

`

class LNSComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = LNSnews;
        this.querySelector('h5').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
        this.querySelector('span').innerText = this.getAttribute('category')
        
    }
}
window.customElements.define('latest-news-side-component', LNSComponent)