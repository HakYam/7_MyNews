const slider = `
<div class="carousel-item active">
<a href="">
    <img src="" class="d-block w-100" alt="...">
    <div class="carousel-text">
        <h3></h3>
    </div>
</a>
</div>`

class SliderComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = slider;
        this.querySelector('h3').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))

    }
}
window.customElements.define('slider-component', SliderComponent)

