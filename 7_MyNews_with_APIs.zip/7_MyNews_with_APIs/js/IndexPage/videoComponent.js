const videos = `
<div class="swiper-slide">
<a href="article.html" class="article-link">
    <div class="slide-img">
        <img src="./images/picture-13.jpg" alt="...">
        <i class="fa-solid fa-play"></i>
    </div>
    <div class="slide-text">
        <h5 class="article-title">
            لوريوم أيكسسيبتيور الأحمد نص
        </h5>
    </div>
</a>
</div>
`

class videosComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = videos;
        this.querySelector('h5').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
    }
}
window.customElements.define('videos-component', videosComponent)
