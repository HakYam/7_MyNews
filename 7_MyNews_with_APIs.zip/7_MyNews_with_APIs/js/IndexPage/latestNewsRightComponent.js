const LNRnews = `
<a href="./article.html" class="article-link">
    <img src="" alt="وصف الصورة">
    <div class="card-text mt-3">
        <span class="article-category"></span>
        <h5 class="article-title"></h5>
        <p></p>
    </div>
</a>
`

class LNRComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = LNRnews;
        this.querySelector('h5').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
        this.querySelector('span').innerText = this.getAttribute('category')
        this.querySelector('p').innerText = this.getAttribute('excerpt')
    }
}
window.customElements.define('latest-news-right-component', LNRComponent)