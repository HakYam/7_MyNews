const headerArticle = `
<a href="article.html" class="article-link">
                                <div class="row">
                                    <div class="col-5">
                                        <img src="" alt="...">
                                    </div>
                                    <div class="col-7">
                                        <div class="article-text">
                                            <span class="article-category"></span>
                                            <h5 class="article-title"></h5>
                                             <p></p>
                                        </div>
                                    </div>
                                </div>
                            </a>`

class headerArticlesComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = headerArticle;
        this.querySelector('h5').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
        this.querySelector('span').innerText = this.getAttribute('category')
        if (this.getAttribute('excerpt')) {
            this.querySelector('p').innerText = this.getAttribute('excerpt')
        } else {
            this.querySelector('p').remove()
        }

    }
}
window.customElements.define('hader-articles-component', headerArticlesComponent)