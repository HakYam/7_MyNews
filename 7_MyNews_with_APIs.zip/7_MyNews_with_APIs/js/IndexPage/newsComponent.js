const news = `
<a href="article.html" class="article-link">
                            <img src="" alt="">
                            <div class="article-text mt-3">
                                <span class="article-category"></span>
                                <h5 class="article-title"></h5>
                                <p></p>
                            </div>
                        </a>`

class newsComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = news;
        this.querySelector('h5').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
        this.querySelector('span').innerText = this.getAttribute('category')
        if (this.getAttribute('excerpt')) {
            this.querySelector('p').innerText = this.getAttribute('excerpt')
        } else {
            this.querySelector('p').remove()
        }

    }
}
window.customElements.define('news-component', newsComponent)