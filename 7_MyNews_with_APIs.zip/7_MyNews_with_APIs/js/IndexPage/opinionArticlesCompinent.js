const opinionArticles = `

    <a href="./article.html">
     <div class="opinions-card">
        <h5></h5>
         <div class="user-info">
            <img src="" alt="...">
            <span></span>
         </div>
     </div>
    </a>

`

class opinionArticlesComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = opinionArticles;
        this.querySelector('h5').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
        this.querySelector('span').innerText = this.getAttribute('username')
    }
}
window.customElements.define('opinion-articles-component', opinionArticlesComponent)
