const mostReadNewsBGimage =  `<div class="card-news">
<a href="article.html">
    <div class="card-img">
        <img src="" alt="">
    </div>
    <div class="card-text pt-3">
        <h4> <h4>
        <time datetime=""></time>

    </div>
</a>
</div>`

class mostReadNewsBGimageComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = mostReadNewsBGimage;
        this.querySelector('h4').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
        this.querySelector('time').innerText = this.getAttribute('date')
    }
}

window.customElements.define('mostreadrews-bgimg-component', mostReadNewsBGimageComponent)
