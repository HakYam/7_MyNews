const mostReadnews = `
<div class="card-news">
<a href="article.html">
    <div class="row">
        <div class="col-md-5">
            <img src="" alt="">
        </div>

        <div class="col-md-7">
            <div class="card-text">
                <h4></h4>
                <p></p>
                <time datetime=""></time>
            </div>
        </div>
    </div>
</a>
</div>`


class mostReadNewsComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = mostReadnews;
        this.querySelector('h4').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
        this.querySelector('time').innerText = this.getAttribute('date')
        if (this.getAttribute('excerpt')) {
            this.querySelector('p').innerText = this.getAttribute('excerpt')
        } else {
            this.querySelector('p').remove()
        }

    }
}
window.customElements.define('mostreadrews-component', mostReadNewsComponent)
