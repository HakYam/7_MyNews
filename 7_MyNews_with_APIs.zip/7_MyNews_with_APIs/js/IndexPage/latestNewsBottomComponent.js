const LNBnews = `
<a href="" class="article-link">
    <img src="" alt="وصف الصورة">
    <div class="card-text mt-3">
        <span class="article-category"></span>
        <h5 class="article-title"></h5>
    </div>
</a>
`

class LNBComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = LNBnews;
        this.querySelector('h5').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
        this.querySelector('span').innerText = this.getAttribute('category')
        
    }
}
window.customElements.define('latest-news-bottom-component', LNBComponent)