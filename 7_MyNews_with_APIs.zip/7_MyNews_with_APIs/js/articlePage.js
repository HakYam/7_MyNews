import { API_URL } from "./urls.js";


async function articleFetch() {
    let response = await fetch(API_URL + 'articles');
    let articles = await response.json();
    

    for (let i = 0; i < articles.length; i++) {
        console.log(`Processing article ${i}:`, articles[i]); // Log each article being processed
        // Your existing code for creating elements and setting attributes...
    }
    
    for (let i = 0; i < articles.length; i++) {
        const el = document.createElement('article-header-component');
        
        el.setAttribute('category', articles[i].category);
        console.log('Category:', articles[i].category);

        el.setAttribute('subject', articles[i].subject);
        el.setAttribute('title', articles[i].title);
        el.setAttribute('image', articles[i].img_uri);
        el.setAttribute('subtitle', articles[i].subtitle);
        el.setAttribute('dateTime', articles[i].datetime);
        
        // Assuming 'articles-container' is the ID of the container where you want to append these elements
        document.getElementById('articles-container').appendChild(el);
    }
}

articleFetch();
