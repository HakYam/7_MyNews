import { API_URL } from "./urls.js";

async function sliderFetch() {
    let response = await fetch(API_URL + 'slider');
    let data = await response.json();
    data.map(slide => {
        const el = document.createElement('slider-component');
        // in config.js window.customElements.define('slider-component', SliderComponent)
        el.setAttribute('image', slide.img_uri);
        el.setAttribute('link', slide.link);
        el.setAttribute('title', slide.title);

        document.getElementById('carousel-inner').appendChild(el);
    })
    let slides = document.getElementsByClassName('carousel-item');
    slides[0].classList.add('active');
}
sliderFetch();

// In your JavaScript code, the response, data, el variables are used in two separate asynchronous functions, 
// sliderFetch and headerArticlesFetch. Each of these functions has its own scope

// The key point here is that each function has its own execution context. 
// Variables declared within a function are local to that function 
// and do not affect or get affected by variables with the same name in other functions or the global scope.
async function headerArticlesFetch() {
    let response = await fetch(API_URL + 'header-articles');
    let data = await response.json();
    data.map(headerArticle => {
        const el = document.createElement('hader-articles-component');
        el.setAttribute('image', headerArticle.img_uri);
        el.setAttribute('link', headerArticle.link);
        el.setAttribute('title', headerArticle.title);
        el.setAttribute('category', headerArticle.category);

        document.getElementById('header-articles').appendChild(el);
    });
}
headerArticlesFetch();

async function newsFetch() {
    let response = await fetch(API_URL + 'news');
    let data = await response.json();
    data.map(news => {
        const el = document.createElement('news-component');
        el.setAttribute('image', news.img_uri);
        el.setAttribute('link', news.link);
        el.setAttribute('title', news.title);
        el.setAttribute('category', news.category);
        el.classList.add("col-lg-3", "col-md-4", "col-sm-6", "mt-4");

        document.getElementById('news').appendChild(el);
    });
}
newsFetch();


async function mostReadFetch() {
    let response = await fetch(API_URL + 'most-read');
    let data = await response.json();
    for (let i = 0; i < data.length; i++) {
        let el; // Declare el outside the if/else
        if (i % 2 == 0) { // if is true > el is 0 or 2
            el = document.createElement('mostreadrews-component');
        } else { // if false > el is 1 
            el = document.createElement('mostreadrews-bgimg-component');
        }
        // Set attributes common to both elements
        el.setAttribute('image', data[i].img_uri);
        el.setAttribute('link', data[i].link);
        el.setAttribute('title', data[i].title);
        el.setAttribute('excerpt', data[i].paragraph);
        el.setAttribute('date', moment(parseInt(data[i].date)).format('dddd') + '، ' + moment(parseInt(data[i].date)).format('LL'));

        // Append the element within the loop
        document.getElementById('most-read').appendChild(el);
    }
}
mostReadFetch();


async function newsOpinionFetch() {
    let response = await fetch(API_URL + 'opinion-articles');
    let data = await response.json();
    data.map(newsOpinion => {
        const el = document.createElement('opinion-articles-component');
        el.setAttribute('image', newsOpinion.user_uri);
        el.setAttribute('link', newsOpinion.link);
        el.setAttribute('title', newsOpinion.title);
        el.setAttribute('username', newsOpinion.user_name);

        el.classList.add("col-lg-3", "col-md-4", "col-sm-6");

        document.getElementById('opinion-articles').appendChild(el);
    });
}
newsOpinionFetch();

async function newsVideosFetch() {
    let response = await fetch(API_URL + 'videos');
    let data = await response.json();
    data.map(vid => {
        let el = document.createElement('videos-component');
        el.setAttribute('image', vid.img_uri);
        el.setAttribute('link', vid.link);
        el.setAttribute('title', vid.title);
        el.classList.add("swiper-slide");

        document.getElementById('videos-component').appendChild(el);
    });
}
newsVideosFetch();

async function latestNewsFetch() {
    let response = await fetch(API_URL + 'latest-news');
    if (!response.ok) {
        console.error('Network response was not ok.');
        return;
    }
    let data = await response.json();

    for (let i = 0; i < data.length; i++) {
        let el;
        if (data[i].position == 'right') {
            el = document.createElement('latest-news-right-component');
            el.setAttribute('image', data[i].img_uri);
            el.setAttribute('link', data[i].link);
            el.setAttribute('title', data[i].title);
            el.setAttribute('excerpt', data[i].paragraph);
            el.setAttribute('position', data[i].position);
            el.setAttribute('category', data[i].category);
            document.getElementById('latest-news-right-component').appendChild(el);
            
        } if (data[i].position == 'side') {
            el = document.createElement('latest-news-side-component');
            el.setAttribute('image', data[i].img_uri);
            el.setAttribute('link', data[i].link);
            el.setAttribute('title', data[i].title);
            el.setAttribute('excerpt', data[i].paragraph);
            el.setAttribute('position', data[i].position);
            el.setAttribute('category', data[i].category);
            document.getElementById('latest-news-side-component').appendChild(el);
        }
         if (data[i].position == 'bottom') {
            el = document.createElement('latest-news-bottom-component');
            el.setAttribute('image', data[i].img_uri);
            el.setAttribute('link', data[i].link);
            el.setAttribute('title', data[i].title);
            el.setAttribute('excerpt', data[i].paragraph);
            el.setAttribute('position', data[i].position);
            el.setAttribute('category', data[i].category);
            el.classList.add("col-sm-6");
            document.getElementById('latest-news-bottom-component').appendChild(el);
        }
       
    }
}


latestNewsFetch();