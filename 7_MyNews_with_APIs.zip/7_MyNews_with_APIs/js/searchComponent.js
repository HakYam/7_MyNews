
import { API_URL } from "./urls.js";
async function searchFetch() {
    let response = await fetch(API_URL + 'search-article');
         let data = await response.json();
 
         for (let i = 0; i < data.length; i++) {
             let el = document.createElement('search-component');
             el.setAttribute('image', data[i].img_uri);
             el.setAttribute('link', data[i].link);
             el.setAttribute('title', data[i].title);
             el.setAttribute('excerpt', data[i].paragraph);
             el.setAttribute('date', moment(parseInt(data[i].date)).format('dddd') + '، ' + moment(parseInt(data[i].date)).format('LL'));
 
             document.getElementById('search-articles').appendChild(el);
         }
 }
 
 searchFetch();
 

const search = `<div class="article-card mt-2">
<a href="article.html" class="article-link">
    <div class="row">
        <div class="col-md-4">

            <img src="./images/picture-12.jpg" alt="وصف الصورة">
        </div>
        <div class="col-md-8">
            <h4>لوريم أيبسوم (Lorem Ipsum)</h4>
            <p>
                لوريم ايبسوم هو نموذج افتراضي يوضع في التصاميم لتعرض على العميل ليظهر
                ويكون
                فيصوره
            </p>
            <time datatime="2022-01-01">2022-01-01 الخميس</time>
        </div>
    </div>
</a>
</div>`

class searchComponent extends HTMLElement {
    constructor() {
        super();
    }
    connectedCallback() {
        this.innerHTML = search;
        this.querySelector('h4').innerText = this.getAttribute('title')
        this.querySelector('a').setAttribute('href', this.getAttribute('link'))
        this.querySelector('img').setAttribute('src', this.getAttribute('image'))
        this.querySelector('time').innerText = this.getAttribute('date')
        this.querySelector('p').setAttribute('src', this.getAttribute('excerpt'))

    }
}
window.customElements.define('search-component', searchComponent)